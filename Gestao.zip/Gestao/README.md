# Prova - Desenvolvimento de uma API com Banco de Dados

Desenvolvido por Bruno Vigo

Objetivo: Realizar a implementação de uma API básica em Spring Boot com banco de dados MySQL ou HSQLDB. 

API desenvolvida em Java com Spring Boot, utilizando banco de dados deve HSQLDB.

Neste trabalho se encontra uma classe criada "Cliente", com uma chave primaria definida e mais três colunas definidas com seu preenchimento necessário.


